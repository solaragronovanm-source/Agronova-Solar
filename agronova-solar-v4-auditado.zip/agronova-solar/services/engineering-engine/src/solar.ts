import type { SolarInput, SolarResult, SolarHourlyGeneration } from "./types.ts";
import { stableHash, ENGINE_VERSION } from "./hash.ts";

/**
 * Curva de distribuição horária de irradiância (6h-18h), normalizada para somar 1.
 * É uma curva de referência (formato "sino") usada apenas para distribuir a energia diária
 * estimada entre as horas de sol — NÃO substitui dado real de irradiância horária quando
 * este estiver disponível (Prompt Master §8: "nunca usar somente média mensal quando existir
 * curva horária real" aplica-se igualmente aqui).
 */
const DAYLIGHT_WEIGHTS: Record<number, number> = {
  6: 0.01, 7: 0.03, 8: 0.06, 9: 0.09, 10: 0.11, 11: 0.12, 12: 0.12,
  13: 0.12, 14: 0.11, 15: 0.09, 16: 0.06, 17: 0.03, 18: 0.01,
  // horas restantes = 0 (sem geração)
};
const WEIGHT_SUM = Object.values(DAYLIGHT_WEIGHTS).reduce((a, b) => a + b, 0);

const DEFAULT_PERFORMANCE_RATIO = 0.8;

/**
 * Calcula geração solar hora a hora e cruza com a carga real para obter autoconsumo/excedente.
 * Determinístico: mesmo input sempre produz o mesmo output (input_hash/output_hash rastreáveis).
 */
export function calculateSolarGeneration(input: SolarInput): SolarResult {
  const performanceRatio = input.performanceRatio ?? DEFAULT_PERFORMANCE_RATIO;
  if (!Number.isFinite(performanceRatio) || performanceRatio <= 0 || performanceRatio > 1) {
    throw new Error("performanceRatio deve estar entre 0 e 1");
  }
  if (!input.loadReadings.length) throw new Error("loadReadings deve conter ao menos uma leitura");
  if (input.potenciaKwp <= 0 || !Number.isFinite(input.potenciaKwp)) {
    throw new Error("potenciaKwp deve ser maior que zero");
  }
  if (input.irradiacaoMediaKwhM2Dia <= 0) {
    throw new Error(
      "irradiacaoMediaKwhM2Dia é obrigatória e deve vir de fonte real (base local/INMET/NASA POWER) — " +
      "o Engineering Engine não assume um valor de irradiância por padrão (Prompt Master: nunca aproximar quando dado real é exigido)."
    );
  }

  const geracaoDiariaKwh = input.potenciaKwp * input.irradiacaoMediaKwhM2Dia * performanceRatio;

  const dias = [...new Set(input.loadReadings.map((r) => r.data))].sort();
  const geracaoHoraria: SolarHourlyGeneration[] = [];
  for (const data of dias) {
    for (const [horaStr, peso] of Object.entries(DAYLIGHT_WEIGHTS)) {
      const hora = Number(horaStr);
      geracaoHoraria.push({
        data,
        hora,
        geracaoKwh: Number(((geracaoDiariaKwh * peso) / WEIGHT_SUM).toFixed(4)),
      });
    }
  }

  const geracaoPorHora = new Map<string, number>();
  for (const g of geracaoHoraria) geracaoPorHora.set(`${g.data}|${g.hora}`, g.geracaoKwh);

  let autoconsumoKwh = 0;
  let geracaoTotalKwh = 0;
  for (const g of geracaoHoraria) geracaoTotalKwh += g.geracaoKwh;

  for (const reading of input.loadReadings) {
    const geracao = geracaoPorHora.get(`${reading.data}|${reading.hora}`) ?? 0;
    autoconsumoKwh += Math.min(geracao, reading.consumoKwh);
  }
  const excedenteKwh = Math.max(0, geracaoTotalKwh - autoconsumoKwh);

  const diasNaAmostra = dias.length || 1;
  const geracaoAnualEstimadaKwh = Number(((geracaoTotalKwh / diasNaAmostra) * 365).toFixed(2));

  const premissas = {
    performanceRatio,
    irradiacaoMediaKwhM2Dia: input.irradiacaoMediaKwhM2Dia,
    curvaDistribuicaoHoraria: "sintética 6h-18h (substituir por dado real quando disponível)",
    diasNaAmostra,
  };

  return {
    engineVersion: ENGINE_VERSION,
    inputHash: stableHash({ potenciaKwp: input.potenciaKwp, irradiacaoMediaKwhM2Dia: input.irradiacaoMediaKwhM2Dia, performanceRatio, nReadings: input.loadReadings.length }),
    geracaoHoraria,
    geracaoAnualEstimadaKwh,
    autoconsumoKwh: Number(autoconsumoKwh.toFixed(2)),
    excedenteKwh: Number(excedenteKwh.toFixed(2)),
    premissas,
  };
}
