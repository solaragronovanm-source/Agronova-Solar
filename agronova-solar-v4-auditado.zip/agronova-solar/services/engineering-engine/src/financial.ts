import type { FinancialInput, FinancialResult } from "./types.ts";

const DEFAULT_TAXA_DESCONTO_MES_PCT = 1.0;

/** VPL (NPV) de um fluxo de caixa mensal, com investimento inicial negativo no mês 0. */
function calcularVpl(fluxos: number[], taxaAoMesPct: number): number {
  const taxa = taxaAoMesPct / 100;
  return fluxos.reduce((acc, fluxo, mes) => acc + fluxo / Math.pow(1 + taxa, mes), 0);
}

/** TIR (IRR) mensal via busca binária sobre a taxa que zera o VPL. Retorna null se não converge. */
function calcularTir(fluxos: number[]): number | null {
  let low = -0.5; // -50% a.m.
  let high = 1.0; // 100% a.m.
  const vplEm = (taxa: number) => fluxos.reduce((acc, fluxo, mes) => acc + fluxo / Math.pow(1 + taxa, mes), 0);

  if (vplEm(low) * vplEm(high) > 0) return null; // sem raiz no intervalo — sinaliza insuficiência, não estima

  for (let i = 0; i < 100; i++) {
    const mid = (low + high) / 2;
    const vplMid = vplEm(mid);
    if (Math.abs(vplMid) < 1e-6) return Number((mid * 100).toFixed(4));
    if (vplEm(low) * vplMid < 0) high = mid;
    else low = mid;
  }
  return Number((((low + high) / 2) * 100).toFixed(4));
}

function calcularPayback(fluxosAcumulados: number[]): number | null {
  for (let mes = 0; mes < fluxosAcumulados.length; mes++) {
    if (fluxosAcumulados[mes] >= 0) return mes;
  }
  return null; // dados insuficientes para payback dentro do horizonte informado — nunca estimar além do fornecido
}

export function calculateFinancials(input: FinancialInput): FinancialResult {
  if (input.capexReais <= 0) throw new Error("capexReais deve ser maior que zero");
  if (input.economiaMensalReais.length === 0) throw new Error("economiaMensalReais não pode ser vazio");

  const taxaDesconto = input.taxaDescontoAoMesPct ?? DEFAULT_TAXA_DESCONTO_MES_PCT;
  if (taxaDesconto <= -100 || !Number.isFinite(taxaDesconto)) throw new Error("taxaDescontoAoMesPct deve ser maior que -100%");
  const opex = input.opexMensalReais ?? 0;
  if (!Number.isFinite(opex) || opex < 0) throw new Error("opexMensalReais deve ser numérico e não negativo");

  const fluxoLiquidoMensal = input.economiaMensalReais.map((economia) => economia - opex);
  const fluxos = [-input.capexReais, ...fluxoLiquidoMensal];

  const acumulado: number[] = [];
  fluxos.reduce((acc, f, i) => (acumulado[i] = acc + f), 0);
  let soma = 0;
  for (let i = 0; i < fluxos.length; i++) {
    soma += fluxos[i];
    acumulado[i] = soma;
  }

  const paybackSimplesMeses = calcularPayback(acumulado);

  const fluxosDescontados = fluxos.map((f, mes) => f / Math.pow(1 + taxaDesconto / 100, mes));
  const acumuladoDescontado: number[] = [];
  let somaD = 0;
  for (let i = 0; i < fluxosDescontados.length; i++) {
    somaD += fluxosDescontados[i];
    acumuladoDescontado[i] = somaD;
  }
  const paybackDescontadoMeses = calcularPayback(acumuladoDescontado);

  const vplReais = Number(calcularVpl(fluxos, taxaDesconto).toFixed(2));
  const tirAoMesPct = calcularTir(fluxos);

  return {
    paybackSimplesMeses,
    paybackDescontadoMeses,
    tirAoMesPct,
    vplReais,
    premissas: {
      taxaDescontoAoMesPct: taxaDesconto,
      opexMensalReais: opex,
      horizonteMeses: input.economiaMensalReais.length,
    },
  };
}
