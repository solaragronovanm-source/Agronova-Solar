import type { LoadReading, ScenarioResult, TariffInput } from "./types.ts";
import { calculateSolarGeneration } from "./solar.ts";
import { sizeBess } from "./bess.ts";
import { calculateFinancials } from "./financial.ts";

export interface BuildScenariosInput {
  loadReadings: LoadReading[];
  tariff: TariffInput;
  potenciaKwpProposta: number;
  irradiacaoMediaKwhM2Dia: number;
  demandaContratadaKw?: number;
  demandaMedidaMaximaKw?: number;
  capexPorKwpReais: number; // premissa explícita — nunca embutida sem declarar (§10, §16)
  capexPorKwhBessReais: number;
  horizonteMeses?: number; // default 120 (10 anos)
}

/** Custo médio de energia (R$/kWh) combinando TE + TUSD — usado para converter kWh evitado em R$. */
function custoMedioReaisPorKwh(tariff: TariffInput): number {
  return tariff.teReaisPorKwh + tariff.tusdReaisPorKwh;
}

function economiaMensalDeGeracao(autoconsumoKwh: number, diasNaAmostra: number, custoKwh: number): number[] {
  const economiaDiariaReais = (autoconsumoKwh / diasNaAmostra) * custoKwh;
  const meses = 120;
  return Array.from({ length: meses }, () => Number((economiaDiariaReais * 30).toFixed(2)));
}

/**
 * Constrói cenários S0 (atual), S1 (Solar) e S2 (Solar+BESS) a partir de uma amostra de
 * memória de massa real. Cada cenário declara CAPEX e premissas explícitas — nada é
 * assumido silenciosamente (Prompt Master §17, §18: nunca escolher automaticamente pelo
 * menor payback, sempre mostrar cenários lado a lado para decisão humana).
 */
export function buildScenarios(input: BuildScenariosInput): ScenarioResult[] {
  if (input.tariff.teReaisPorKwh < 0 || input.tariff.tusdReaisPorKwh < 0) throw new Error("TE/TUSD não podem ser negativos");
  if (input.potenciaKwpProposta <= 0 || input.capexPorKwpReais <= 0 || input.capexPorKwhBessReais <= 0) throw new Error("potência e CAPEX devem ser maiores que zero");
  if (input.horizonteMeses !== undefined && (!Number.isInteger(input.horizonteMeses) || input.horizonteMeses <= 0)) throw new Error("horizonteMeses deve ser inteiro maior que zero");
  const custoKwh = custoMedioReaisPorKwh(input.tariff);
  const diasNaAmostra = new Set(input.loadReadings.map((r) => r.data)).size || 1;
  const horizonte = input.horizonteMeses ?? 120;

  const s0: ScenarioResult = {
    codigo: "S0",
    nome: "Situação atual (sem intervenção)",
    capexReais: 0,
    economiaAnualReais: 0,
    financeiro: {
      paybackSimplesMeses: null,
      paybackDescontadoMeses: null,
      tirAoMesPct: null,
      vplReais: 0,
      premissas: { observacao: "Cenário de referência — sem investimento" },
    },
  };

  const solar = calculateSolarGeneration({
    loadReadings: input.loadReadings,
    potenciaKwp: input.potenciaKwpProposta,
    irradiacaoMediaKwhM2Dia: input.irradiacaoMediaKwhM2Dia,
  });
  const capexSolar = Number((input.potenciaKwpProposta * input.capexPorKwpReais).toFixed(2));
  const economiaMensalSolar = economiaMensalDeGeracao(solar.autoconsumoKwh, diasNaAmostra, custoKwh).slice(0, horizonte);
  const financeiroSolar = calculateFinancials({ capexReais: capexSolar, economiaMensalReais: economiaMensalSolar });

  const s1: ScenarioResult = {
    codigo: "S1",
    nome: "Solar",
    capexReais: capexSolar,
    economiaAnualReais: Number((economiaMensalSolar.slice(0, 12).reduce((a, b) => a + b, 0)).toFixed(2)),
    financeiro: financeiroSolar,
    solar,
  };

  let s2: ScenarioResult | null = null;
  if (input.demandaContratadaKw && input.demandaMedidaMaximaKw && input.demandaMedidaMaximaKw > input.demandaContratadaKw) {
    const bess = sizeBess({
      loadReadings: input.loadReadings,
      solarGeneration: solar.geracaoHoraria,
      aplicacao: "peak_shaving",
      demandaContratadaKw: input.demandaContratadaKw,
      demandaMedidaMaximaKw: input.demandaMedidaMaximaKw,
    });
    const capexBess = Number((bess.capacidadeRecomendadaKwh * input.capexPorKwhBessReais).toFixed(2));
    const capexTotal = Number((capexSolar + capexBess).toFixed(2));
    // Economia adicional do BESS: evita ultrapassagem de demanda — estimativa requer tarifa de
    // demanda (precoDemandaReaisPorKw); sem ela, o cenário reporta apenas a economia solar e
    // sinaliza a insuficiência de dado em vez de estimar.
    const economiaDemandaMensal = input.tariff.precoDemandaReaisPorKw
      ? Array.from({ length: horizonte }, () =>
          Number(((input.demandaMedidaMaximaKw! - input.demandaContratadaKw!) * input.tariff.precoDemandaReaisPorKw!).toFixed(2))
        )
      : Array.from({ length: horizonte }, () => 0);
    const economiaMensalTotal = economiaMensalSolar.map((v, i) => v + economiaDemandaMensal[i]);
    const financeiroTotal = calculateFinancials({ capexReais: capexTotal, economiaMensalReais: economiaMensalTotal });

    s2 = {
      codigo: "S2",
      nome: "Solar + BESS (peak shaving)",
      capexReais: capexTotal,
      economiaAnualReais: Number(economiaMensalTotal.slice(0, 12).reduce((a, b) => a + b, 0).toFixed(2)),
      financeiro: financeiroTotal,
      solar,
      bess,
      ...(input.tariff.precoDemandaReaisPorKw
        ? {}
        : { financeiro: { ...financeiroTotal, premissas: { ...financeiroTotal.premissas, aviso: "precoDemandaReaisPorKw não informado — economia de demanda não incluída no financeiro" } } }),
    };
  }

  return s2 ? [s0, s1, s2] : [s0, s1];
}
