import { createHash } from "node:crypto";

/**
 * Canonicaliza recursivamente objetos/arrays para que a mesma estrutura produza
 * sempre o mesmo hash, independentemente da ordem das chaves.
 */
function canonicalize(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([key, item]) => [key, canonicalize(item)])
    );
  }
  return value;
}

/** Hash determinístico de qualquer input/output do Engineering Engine. */
export function stableHash(value: unknown): string {
  const json = JSON.stringify(canonicalize(value));
  return createHash("sha256").update(json).digest("hex").slice(0, 16);
}

export const ENGINE_VERSION = "engineering-engine@0.1.1";
