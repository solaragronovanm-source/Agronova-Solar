import { describe, it, expect } from "vitest";
import { calculateSolarGeneration, sizeBess, calculateFinancials, buildScenarios, LoadReading } from "../src/index.ts";

/** Gera 3 dias de leitura horária com um pico de demanda das 18h-21h (perfil industrial típico). */
function fixtureLoadReadings(): LoadReading[] {
  const dias = ["2026-01-05", "2026-01-06", "2026-01-07"];
  const readings: LoadReading[] = [];
  for (const data of dias) {
    for (let hora = 0; hora < 24; hora++) {
      const pico = hora >= 18 && hora <= 21;
      const consumoKwh = pico ? 120 : 60;
      readings.push({ data, hora, consumoKwh, demandaKw: consumoKwh, posto: hora >= 18 && hora < 21 ? "ponta" : "fora_ponta" });
    }
  }
  return readings;
}

describe("Solar Engine", () => {
  it("calcula geração proporcional a kWp e irradiação, sem exceder o volume diário esperado", () => {
    const readings = fixtureLoadReadings();
    const result = calculateSolarGeneration({
      loadReadings: readings,
      potenciaKwp: 100,
      irradiacaoMediaKwhM2Dia: 5.2,
      performanceRatio: 0.8,
    });

    const geracaoDiariaEsperada = 100 * 5.2 * 0.8; // kWh/dia
    const geracaoPorDia = result.geracaoHoraria
      .filter((g) => g.data === "2026-01-05")
      .reduce((acc, g) => acc + g.geracaoKwh, 0);

    expect(geracaoPorDia).toBeCloseTo(geracaoDiariaEsperada, 1);
    expect(result.autoconsumoKwh).toBeGreaterThan(0);
    expect(result.autoconsumoKwh).toBeLessThanOrEqual(result.geracaoAnualEstimadaKwh);
    expect(result.engineVersion).toContain("engineering-engine");
  });

  it("recusa calcular sem irradiação real (nunca aproxima dado obrigatório)", () => {
    const readings = fixtureLoadReadings();
    expect(() =>
      calculateSolarGeneration({ loadReadings: readings, potenciaKwp: 100, irradiacaoMediaKwhM2Dia: 0 })
    ).toThrow(/irradiacaoMediaKwhM2Dia/);
  });
});

describe("BESS Engine", () => {
  it("dimensiona peak shaving apenas quando há ultrapassagem real de demanda", () => {
    const readings = fixtureLoadReadings();
    const result = sizeBess({
      loadReadings: readings,
      aplicacao: "peak_shaving",
      demandaContratadaKw: 80,
      demandaMedidaMaximaKw: 120,
    });

    expect(result.potenciaRecomendadaKw).toBeCloseTo(40, 0); // 120 - 80
    expect(result.capacidadeRecomendadaKwh).toBeGreaterThan(0);
    expect(result.evidencias.some((e) => e.includes("ultrapassagem"))).toBe(true);
  });

  it("não recomenda BESS quando a demanda medida não ultrapassa a contratada", () => {
    const readings = fixtureLoadReadings();
    const result = sizeBess({
      loadReadings: readings,
      aplicacao: "peak_shaving",
      demandaContratadaKw: 150, // acima do pico real (120)
      demandaMedidaMaximaKw: 120,
    });

    expect(result.potenciaRecomendadaKw).toBe(0);
    expect(result.capacidadeRecomendadaKwh).toBe(0);
    expect(result.justificativa).toMatch(/não há evidência/i);
  });

  it("exige verificação de demanda antes de dimensionar (não aceita dados incompletos)", () => {
    const readings = fixtureLoadReadings();
    expect(() => sizeBess({ loadReadings: readings, aplicacao: "peak_shaving" })).toThrow(
      /demandaContratadaKw e demandaMedidaMaximaKw/
    );
  });

  it("não confunde arbitragem tarifária com solar_shifting — arbitragem exige série tarifária própria", () => {
    const readings = fixtureLoadReadings();
    expect(() => sizeBess({ loadReadings: readings, aplicacao: "arbitragem" })).toThrow(
      /arbitragem tarifária ainda não está implementada/
    );
  });
});

describe("Financial Engine", () => {
  it("calcula payback simples corretamente para um fluxo conhecido", () => {
    // CAPEX 12000, economia de 1000/mês → payback simples = mês 12
    const result = calculateFinancials({
      capexReais: 12000,
      economiaMensalReais: Array.from({ length: 24 }, () => 1000),
    });
    expect(result.paybackSimplesMeses).toBe(12);
    expect(result.vplReais).toBeDefined();
  });

  it("retorna payback null quando o horizonte informado não é suficiente para recuperar o CAPEX", () => {
    const result = calculateFinancials({
      capexReais: 100000,
      economiaMensalReais: Array.from({ length: 12 }, () => 1000), // só cobre 12k em 1 ano
    });
    expect(result.paybackSimplesMeses).toBeNull();
  });

  it("calcula TIR consistente com um fluxo de retorno positivo conhecido", () => {
    // -1000 no mês 0, +1100 no mês 1 → TIR = 10% a.m.
    const result = calculateFinancials({ capexReais: 1000, economiaMensalReais: [1100] });
    expect(result.tirAoMesPct).not.toBeNull();
    expect(result.tirAoMesPct!).toBeCloseTo(10, 0);
  });
});

describe("Scenario Engine", () => {
  it("monta S0/S1/S2 lado a lado sem escolher automaticamente o melhor", () => {
    const readings = fixtureLoadReadings();
    const scenarios = buildScenarios({
      loadReadings: readings,
      tariff: { teReaisPorKwh: 0.35, tusdReaisPorKwh: 0.25, precoDemandaReaisPorKw: 30 },
      potenciaKwpProposta: 100,
      irradiacaoMediaKwhM2Dia: 5.2,
      demandaContratadaKw: 80,
      demandaMedidaMaximaKw: 120,
      capexPorKwpReais: 3500,
      capexPorKwhBessReais: 2500,
    });

    expect(scenarios.map((s) => s.codigo)).toEqual(["S0", "S1", "S2"]);
    expect(scenarios[1].capexReais).toBeGreaterThan(0);
    expect(scenarios[2].bess).toBeDefined();
    // O motor não deve marcar nenhum cenário como "recomendado" — decisão é humana.
    for (const s of scenarios) expect((s as any).recomendado).toBeUndefined();
  });

  it("gera apenas S0/S1 quando não há evidência de ultrapassagem de demanda para BESS", () => {
    const readings = fixtureLoadReadings();
    const scenarios = buildScenarios({
      loadReadings: readings,
      tariff: { teReaisPorKwh: 0.35, tusdReaisPorKwh: 0.25 },
      potenciaKwpProposta: 100,
      irradiacaoMediaKwhM2Dia: 5.2,
      capexPorKwpReais: 3500,
      capexPorKwhBessReais: 2500,
    });
    expect(scenarios.map((s) => s.codigo)).toEqual(["S0", "S1"]);
  });
});
