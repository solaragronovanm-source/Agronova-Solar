# Agronova Solar V3 — Auditoria Técnica

Data: 2026-09-06

## Resultado executivo

O ZIP contém um **MVP funcional em código**, mas ainda não é uma plataforma pronta para produção. A separação entre API, Engineering Engine, AI Copilot e Automation Engine é uma boa base arquitetural. O principal risco é tratar cálculos comerciais simplificados como se fossem dimensionamento/viabilidade regulatória final.

## Verificações executadas

- Inventário do projeto: **69 tabelas SQL** e módulos de API/engenharia/IA/automação identificados.
- JSONs de configuração: **válidos**.
- Balanceamento sintático básico do SQL: parênteses balanceados. Validação final exige PostgreSQL/CI.
- Engenharia: executada em smoke test isolado com Node 22 + type stripping, sem dependências externas. Resultado para a fixture: Solar 151.840 kWh/ano; BESS peak shaving 40 kW / 188,2 kWh; S0/S1/S2 gerados.
- `npm test` e `npm run typecheck`: **não executáveis neste ambiente**, porque o `node_modules` disponível estava incompleto e faltavam `vitest`, `tsc` e arquivos de runtime do Express. `npm install` não conseguiu concluir antes do timeout do ambiente.

## Correções aplicadas

1. `stableHash()` passou a fazer canonicalização recursiva; a implementação anterior podia gerar hashes iguais para estruturas diferentes.
2. Imports de tipos do Engineering Engine foram marcados como `import type`.
3. Validação de SOC, eficiência, potência, leituras e performance ratio.
4. `arbitragem` não é mais apresentada como implementada: agora retorna erro explícito até existir série tarifária horária + despacho.
5. Validações de cliente, CNPJ, conta de energia, grupo A/B, mercado, memória de massa e oportunidade.
6. CORS passou a aceitar `CORS_ORIGIN`; sem variável continua permissivo apenas para facilitar desenvolvimento.
7. Error handler HTTP adicionado no final da cadeia.
8. Índices/constraints críticos adicionados ao schema PostgreSQL para CNPJ por organização, UC por cliente, leituras temporais e eventos.
9. Dockerfile, `.dockerignore` e `.env.example` adicionados para deploy.

## Problemas críticos que permanecem

### P0 — Segurança / multi-tenancy
Não existe autenticação/RBAC real e os endpoints não isolam dados por organização de forma efetiva. **Não publicar na internet como está.**

### P0 — Persistência
O gateway usa `InMemoryStore`; reiniciar o processo perde todos os clientes, contas, leituras e oportunidades. PostgreSQL precisa substituir esse repositório antes de uso operacional.

### P0 — Tarifação brasileira
O cenário usa `TE + TUSD` como custo médio. Isso é insuficiente para representar todas as regras de faturamento, compensação, demanda, modalidade tarifária, Grupo A/B, Fio B e demais componentes aplicáveis. O resultado deve ser tratado como **pré-estudo**, não proposta financeira definitiva.

### P1 — Solar
A curva horária é sintética e a irradiação média é aplicada aos dias da amostra. Para engenharia comercial robusta, usar série meteorológica/irradiância horária validada, perdas detalhadas, orientação/inclinação, clipping, temperatura, disponibilidade e degradação.

### P1 — BESS
O dimensionamento atual é heurístico para MVP. Peak shaving usa contagem de horas acima do limite para estimar energia; isso não substitui despacho horário, SOC, potência contínua/pico, eficiência por ciclo, limites de C-rate, reserva, degradação e ciclos.

### P1 — CRM / integrações
OCR, prospecção/enriquecimento, catálogo de equipamentos, WhatsApp, Event Bus persistente e frontend de produção continuam pendentes.

## Arquitetura recomendada V3.1

`Frontend → API Gateway → Auth/RBAC → Application Services → PostgreSQL + Event Bus → Engineering Engine / Tariff Registry / Technology Catalog / Integrations`

A IA deve permanecer na camada de interpretação e copiloto, recebendo resultados rastreáveis do Engineering Engine e nunca inventando valores técnicos.

## Ordem de implementação

1. PostgreSQL + migrations + repository layer.
2. Auth/RBAC + tenant isolation + audit log.
3. Tariff Registry versionado, começando por Energisa MT.
4. OCR de conta + validação humana + normalização de memória de massa.
5. Engineering Engine 1.0: Solar + BESS + financeiro regulatório.
6. Technology Catalog brasileiro com fonte, vigência, disponibilidade e preço.
7. CRM completo + propostas + contratos + tarefas.
8. Event Bus + Automation Engine persistente/idempotente.
9. WhatsApp e demais integrações com status `NOT_CONNECTED` quando não configuradas.
10. Frontend de produção + observabilidade + CI/CD.

## Conclusão

A V3 é uma **base de desenvolvimento válida**, não um produto acabado. O maior ganho imediato não é adicionar mais IA: é transformar os dados e cálculos atuais em uma camada de engenharia e tarifação auditável, persistente e segura.
