import { Router } from "express";
import { store } from "../repositories/store.ts";
import { suggestCrossSell } from "@agronova/automation-engine";

export const opportunitiesRouter = Router();

opportunitiesRouter.get("/", (req, res) => {
  res.json([...store.opportunities.values()]);
});

opportunitiesRouter.post("/", (req, res) => {
  const { organizationId, customerId, product, valor } = req.body ?? {};
  if (!organizationId || !customerId || !product) {
    return res.status(400).json({ error: "organizationId, customerId e product são obrigatórios" });
  }
  if (!store.customers.has(customerId)) return res.status(404).json({ error: "cliente não encontrado" });
  if (valor !== undefined && (!Number.isFinite(valor) || valor < 0)) return res.status(400).json({ error: "valor deve ser numérico e não negativo" });
  const opp = store.createOpportunity({ organizationId, customerId, product, valor, status: "aberta", origemCrossSell: false });
  res.status(201).json(opp);
});

/**
 * Marca oportunidade como ganha e retorna sugestões de cross-sell — nunca cria a próxima
 * oportunidade automaticamente, sempre "WAITING_APPROVAL" para o vendedor aprovar (§21).
 */
opportunitiesRouter.post("/:id/won", (req, res) => {
  const opp = store.opportunities.get(req.params.id);
  if (!opp) return res.status(404).json({ error: "oportunidade não encontrada" });
  opp.status = "ganha";
  const crossSell = suggestCrossSell(opp.product);
  res.json({ opportunity: opp, crossSell });
});
