import { Router } from "express";
import { store } from "../repositories/store.ts";

export const energyAccountsRouter = Router();

energyAccountsRouter.post("/", (req, res) => {
  const { customerId, unidadeConsumidora, grupo, modalidade, mercado } = req.body ?? {};
  if (!customerId || !unidadeConsumidora || !grupo) {
    return res.status(400).json({ error: "customerId, unidadeConsumidora e grupo são obrigatórios" });
  }
  if (grupo !== "A" && grupo !== "B") return res.status(400).json({ error: "grupo deve ser A ou B" });
  if (mercado !== undefined && mercado !== "cativo" && mercado !== "livre") return res.status(400).json({ error: "mercado deve ser cativo ou livre" });
  if (!store.customers.has(customerId)) return res.status(404).json({ error: "cliente não encontrado" });
  const acc = store.createEnergyAccount({ customerId, unidadeConsumidora: String(unidadeConsumidora).trim(), grupo, modalidade, mercado: mercado ?? "cativo" });
  res.status(201).json(acc);
});

/**
 * Importa memória de massa (leituras horárias). Espera um array de
 * { data, hora, consumoKwh, demandaKw?, posto? } — o mesmo formato de `load_readings` no
 * schema Postgres. Não faz OCR aqui: este endpoint recebe dado já estruturado
 * (ex.: planilha exportada da distribuidora/Mercado Livre).
 */
energyAccountsRouter.post("/:id/load-profile", (req, res) => {
  const acc = store.energyAccounts.get(req.params.id);
  if (!acc) return res.status(404).json({ error: "conta de energia não encontrada" });
  const readings = req.body?.readings;
  if (!Array.isArray(readings) || readings.length === 0) {
    return res.status(400).json({ error: "readings deve ser um array não vazio de leituras horárias" });
  }
  const invalid = readings.find((r: any) => !r || typeof r.data !== "string" || !Number.isInteger(r.hora) || r.hora < 0 || r.hora > 23 || typeof r.consumoKwh !== "number" || !Number.isFinite(r.consumoKwh) || r.consumoKwh < 0);
  if (invalid) return res.status(400).json({ error: "cada leitura deve conter data, hora inteira 0-23 e consumoKwh numérico não negativo" });
  const salvas = store.addLoadReadings(acc.id, readings);
  res.status(201).json({ importadas: salvas.length });
});

energyAccountsRouter.get("/:id/load-profile", (req, res) => {
  const readings = store.loadReadings.get(req.params.id);
  if (readings === undefined) return res.status(404).json({ error: "conta de energia não encontrada" });
  res.json(readings);
});
