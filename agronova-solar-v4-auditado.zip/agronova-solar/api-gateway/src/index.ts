import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { customersRouter } from "./routes/customers.ts";
import { opportunitiesRouter } from "./routes/opportunities.ts";
import { energyAccountsRouter } from "./routes/energyAccounts.ts";
import { engineeringRouter } from "./routes/engineering.ts";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const corsOrigin = process.env.CORS_ORIGIN;
app.use(cors(corsOrigin ? { origin: corsOrigin } : undefined));
app.use(express.json({ limit: "5mb" }));

app.get("/api/v1/health", (req, res) => res.json({ status: "ok", service: "agronova-api-gateway", version: "0.1.1" }));


app.use("/api/v1/customers", customersRouter);
app.use("/api/v1/opportunities", opportunitiesRouter);
app.use("/api/v1/energy-accounts", energyAccountsRouter);
app.use("/api/v1/engineering", engineeringRouter);

// Frontend mínimo do CRM (public/index.html) — fala com a API acima via fetch().
app.use(express.static(path.join(__dirname, "..", "public")));

// Error handler must be registered after all routes.
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: process.env.NODE_ENV === "production" ? "erro interno do servidor" : err?.message ?? "erro interno do servidor" });
});

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
if (process.env.NODE_ENV !== "test") {
  app.listen(PORT, () => console.log(`Agronova API Gateway ouvindo em http://localhost:${PORT}`));
}

export { app };
