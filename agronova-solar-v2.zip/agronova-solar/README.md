# Agronova Intelligence — Energy Platform

CRM + Prospecção + Digital Twin + Engenharia + BESS + Solar + Mercado Livre + IA + Automação.

Este repositório é o ponto de partida do código da **Agronova Intelligence**, a plataforma
descrita no **Prompt Master V2 (Engineering Platform)** mantido no projeto Claude
"PLATAFORMA BESS". A especificação completa (34 seções + complementos preservados) é a
fonte da verdade de arquitetura — este código deve evoluir para implementá-la, nunca o
contrário.

## Estado atual — o que é real e o que não é

**Funcional e testado (12 testes automatizados passando):**
- `services/engineering-engine` — Solar Engine, BESS Engine, Financial Engine e Scenario
  Engine determinísticos, com fórmulas reais (não mockadas): geração solar por curva
  horária × irradiação real informada, dimensionamento de BESS por verificação de
  demanda contratada×medida (peak shaving) ou excedente solar real (solar shifting),
  payback simples/descontado, TIR (busca binária) e VPL calculados de verdade.
- `services/ai-copilot` — explica os resultados do engine no formato DECISÃO/POR QUÊ/
  DADOS/PREMISSAS/CONFIANÇA/RISCOS/PRÓXIMA AÇÃO. Não calcula nada por conta própria.
- `services/automation-engine` — casa eventos com as regras AUT-001..015 e gera
  sugestões de cross-sell, sempre em estado `WAITING_APPROVAL` (nunca cria oportunidade
  sozinho).
- `api-gateway` — API REST `/api/v1` rodando de verdade (Express), com CRM básico
  (clientes, oportunidades), contas de energia + importação de memória de massa, e os
  endpoints de engenharia (`/engineering/solar`, `/bess`, `/scenarios`) plugados no
  engine acima. Testado ponta a ponta: prospect → cliente (com dedup por CNPJ) → conta
  de energia → memória de massa → cenários S0/S1/S2 → oportunidade → cross-sell.
- **Persistência: em memória** (processo único, dados somem ao reiniciar). O schema de
  produção já existe em `db/schema.sql` (PostgreSQL) — trocar o repositório em memória
  por Prisma/Knex apontando para Postgres é o próximo passo real, sem mudar o formato
  dos dados.

**Ainda não implementado** (documentado como stub/README nos respectivos módulos):
CRM completo (propostas, contratos, pipelines), OCR real de conta de energia, Tariff
Registry/Distribuidoras dinâmico, Technology Catalog, Grid/Transformer/EV/Generator
Engines, WhatsApp, autenticação/RBAC, multi-tenancy de verdade, frontend. Ver os READMEs
de cada `services/*` para o escopo previsto de cada um.

## Como rodar

```bash
npm install
npm run typecheck   # confere todos os workspaces
npm test            # 12 testes (engine + fluxo ponta a ponta da API)
npm run dev:api      # sobe a API em http://localhost:3000
curl http://localhost:3000/api/v1/health
```

## Princípios (do Prompt Master V2)

1. Não vender antes de entender.
2. Não dimensionar sem dados.
3. Não calcular por aproximação quando existirem dados reais.
4. Não deixar a IA inventar dados técnicos — IA interpreta, o Engineering Engine calcula.
5. Toda recomendação deve ser rastreável (DECISÃO, POR QUÊ, DADOS, PREMISSAS, CONFIANÇA).
6. Toda premissa deve ser editável e versionada.
7. Nenhuma oportunidade de cross-sell é criada automaticamente sem aprovação humana.
8. Nenhuma integração inexistente é apresentada como conectada — usar status `NOT_CONNECTED`.

## Estrutura

```
agronova-solar/
├── api-gateway/                 # Camada de entrada da API (versionada /api/v1)
├── services/
│   ├── crm/                     # Cliente 360, leads, oportunidades, propostas, pipelines
│   ├── prospector-intelligence/ # Busca/enriquecimento de prospects, captura no CRM
│   ├── energy-digital-twin/     # Contas, memória de massa, curva de carga
│   ├── ocr/                     # Extração de contas de energia
│   ├── engineering-engine/      # Motor determinístico (independente da IA)
│   │   ├── solar/
│   │   ├── bess/
│   │   ├── financial/
│   │   ├── scenario/
│   │   └── optimization/
│   ├── ai-copilot/              # Interpretação e explicação (nunca calcula)
│   ├── automation-engine/       # Regras AUT-001..AUT-015, Event Bus
│   ├── technology-catalog/      # Fabricantes, modelos, compatibilidade
│   └── whatsapp/                # Geração e envio de mensagens
├── db/
│   ├── schema.sql                # DDL inicial de todas as entidades do Prompt Master
│   └── migrations/               # Migrations incrementais (vazio — a preencher)
└── config/
    ├── automation-rules.json     # AUT-001 a AUT-015
    ├── event-catalog.json        # Eventos mínimos do Event Bus
    ├── product-cross-sell-map.json
    └── tariff-registry-schema.json
```

## Próximos passos sugeridos

1. Escolher stack (linguagem/framework) para `api-gateway` e `services/*` — não definido
   ainda no Prompt Master.
2. Implementar `db/migrations` a partir de `db/schema.sql` na ferramenta de migração
   escolhida (Prisma, Knex, Flyway, etc.).
3. Implementar o Engineering Calculation Engine primeiro (`services/engineering-engine`),
   já que CRM, Prospector e AI Copilot dependem dele para não "chutar" dimensionamento.
4. Conectar o Event Bus real (ex.: Kafka, PostgreSQL LISTEN/NOTIFY, ou fila gerenciada) aos
   eventos listados em `config/event-catalog.json`.

## Referência

Especificação completa: documentos `agronova-intelligence-master-v2-engineering-platform.md`,
`agronova-intelligence-master-prompt-v2.md` e `agronova-prospector-intelligence.md` no
projeto Claude "PLATAFORMA BESS".
