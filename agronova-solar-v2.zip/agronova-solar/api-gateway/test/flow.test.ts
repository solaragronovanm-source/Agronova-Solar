import { describe, it, expect, beforeAll } from "vitest";
import request from "supertest";

process.env.NODE_ENV = "test";

let app: import("express").Express;

beforeAll(async () => {
  ({ app } = await import("../src/index"));
});

function fixtureReadings() {
  const readings: any[] = [];
  for (const data of ["2026-01-05", "2026-01-06", "2026-01-07"]) {
    for (let hora = 0; hora < 24; hora++) {
      const pico = hora >= 18 && hora <= 21;
      const consumoKwh = pico ? 120 : 60;
      readings.push({ data, hora, consumoKwh, demandaKw: consumoKwh });
    }
  }
  return readings;
}

describe("fluxo ponta a ponta: prospect → cliente → conta de energia → memória de massa → cenários → cross-sell", () => {
  it("executa o fluxo completo e nunca cria oportunidade de cross-sell sem aprovação", async () => {
    // 1. Captura de prospect no CRM (com verificação de duplicidade)
    const capture = await request(app)
      .post("/api/v1/customers/capture-from-prospect")
      .send({ organizationId: "org-1", cnpj: "12.345.678/0001-90", nome: "Fazenda Teste", tipo: "rural" })
      .expect(201);
    expect(capture.body.duplicado).toBe(false);
    const customerId = capture.body.customer.id;

    // 1b. Repetir a captura com o mesmo CNPJ deve sinalizar duplicidade, não criar de novo
    const captureDup = await request(app)
      .post("/api/v1/customers/capture-from-prospect")
      .send({ organizationId: "org-1", cnpj: "12.345.678/0001-90", nome: "Fazenda Teste", tipo: "rural" })
      .expect(200);
    expect(captureDup.body.duplicado).toBe(true);
    expect(captureDup.body.acaoSugerida).toBe("ATUALIZAR_CLIENTE");

    // 2. Criar conta de energia
    const account = await request(app)
      .post("/api/v1/energy-accounts")
      .send({ customerId, unidadeConsumidora: "UC-001", grupo: "A", mercado: "cativo" })
      .expect(201);
    const energyAccountId = account.body.id;

    // 3. Importar memória de massa
    await request(app)
      .post(`/api/v1/energy-accounts/${energyAccountId}/load-profile`)
      .send({ readings: fixtureReadings() })
      .expect(201);

    // 4. Calcular cenários (S0/S1/S2) via Engineering Engine
    const scenarios = await request(app)
      .post("/api/v1/engineering/scenarios")
      .send({
        energyAccountId,
        tariff: { teReaisPorKwh: 0.35, tusdReaisPorKwh: 0.25, precoDemandaReaisPorKw: 30 },
        potenciaKwpProposta: 100,
        irradiacaoMediaKwhM2Dia: 5.2,
        demandaContratadaKw: 80,
        demandaMedidaMaximaKw: 120,
        capexPorKwpReais: 3500,
        capexPorKwhBessReais: 2500,
      })
      .expect(200);
    expect(scenarios.body.scenarios.map((s: any) => s.codigo)).toEqual(["S0", "S1", "S2"]);
    expect(scenarios.body.explicacao.decisao).toContain("cenário");

    // 5. Criar e fechar oportunidade Solar
    const opp = await request(app)
      .post("/api/v1/opportunities")
      .send({ organizationId: "org-1", customerId, product: "Solar", valor: 350000 })
      .expect(201);

    const won = await request(app).post(`/api/v1/opportunities/${opp.body.id}/won`).expect(200);
    expect(won.body.opportunity.status).toBe("ganha");
    // Cross-sell nunca é criado automaticamente — sempre aguardando aprovação humana
    expect(won.body.crossSell.estado).toBe("WAITING_APPROVAL");
    expect(won.body.crossSell.produtosSugeridos).toEqual(expect.arrayContaining(["Limpeza", "O&M", "Retrofit", "Storage"]));
  });

  it("recusa calcular engenharia sem memória de massa importada", async () => {
    const customer = await request(app)
      .post("/api/v1/customers")
      .send({ organizationId: "org-1", nome: "Cliente Sem Dados", tipo: "empresa" })
      .expect(201);
    const account = await request(app)
      .post("/api/v1/energy-accounts")
      .send({ customerId: customer.body.id, unidadeConsumidora: "UC-002", grupo: "B" })
      .expect(201);

    const res = await request(app)
      .post("/api/v1/engineering/solar")
      .send({ energyAccountId: account.body.id, potenciaKwp: 50, irradiacaoMediaKwhM2Dia: 5 })
      .expect(422);
    expect(res.body.error).toMatch(/memória de massa/i);
  });
});
