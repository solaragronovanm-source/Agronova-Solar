import { Router } from "express";
import { store } from "../repositories/store";

export const energyAccountsRouter = Router();

energyAccountsRouter.post("/", (req, res) => {
  const { customerId, unidadeConsumidora, grupo, modalidade, mercado } = req.body ?? {};
  if (!customerId || !unidadeConsumidora || !grupo) {
    return res.status(400).json({ error: "customerId, unidadeConsumidora e grupo são obrigatórios" });
  }
  const acc = store.createEnergyAccount({ customerId, unidadeConsumidora, grupo, modalidade, mercado: mercado ?? "cativo" });
  res.status(201).json(acc);
});

/**
 * Importa memória de massa (leituras horárias). Espera um array de
 * { data, hora, consumoKwh, demandaKw?, posto? } — o mesmo formato de `load_readings` no
 * schema Postgres. Não faz OCR aqui: este endpoint recebe dado já estruturado
 * (ex.: planilha exportada da distribuidora/Mercado Livre).
 */
energyAccountsRouter.post("/:id/load-profile", (req, res) => {
  const acc = store.energyAccounts.get(req.params.id);
  if (!acc) return res.status(404).json({ error: "conta de energia não encontrada" });
  const readings = req.body?.readings;
  if (!Array.isArray(readings) || readings.length === 0) {
    return res.status(400).json({ error: "readings deve ser um array não vazio de leituras horárias" });
  }
  const salvas = store.addLoadReadings(acc.id, readings);
  res.status(201).json({ importadas: salvas.length });
});

energyAccountsRouter.get("/:id/load-profile", (req, res) => {
  const readings = store.loadReadings.get(req.params.id);
  if (readings === undefined) return res.status(404).json({ error: "conta de energia não encontrada" });
  res.json(readings);
});
