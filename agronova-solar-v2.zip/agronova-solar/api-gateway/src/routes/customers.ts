import { Router } from "express";
import { store } from "../repositories/store";

export const customersRouter = Router();

customersRouter.get("/", (req, res) => {
  res.json([...store.customers.values()]);
});

customersRouter.post("/", (req, res) => {
  const { organizationId, nome, tipo, cnpj } = req.body ?? {};
  if (!organizationId || !nome || !tipo) {
    return res.status(400).json({ error: "organizationId, nome e tipo são obrigatórios" });
  }
  const customer = store.createCustomer({ organizationId, nome, tipo, cnpj });
  res.status(201).json(customer);
});

customersRouter.get("/:id", (req, res) => {
  const customer = store.customers.get(req.params.id);
  if (!customer) return res.status(404).json({ error: "cliente não encontrado" });
  res.json(customer);
});

/**
 * Fluxo `CAPTURAR NO CRM` (Prospector Intelligence, complemento preservado):
 * verifica duplicidade por CNPJ antes de criar — se já existe, retorna o cliente existente
 * com `duplicado: true` em vez de criar um novo registro.
 */
customersRouter.post("/capture-from-prospect", (req, res) => {
  const { organizationId, cnpj, nome, tipo } = req.body ?? {};
  if (!organizationId || !cnpj || !nome || !tipo) {
    return res.status(400).json({ error: "organizationId, cnpj, nome e tipo são obrigatórios" });
  }
  const existente = store.findCustomerByCnpj(cnpj);
  if (existente) {
    return res.status(200).json({ duplicado: true, customer: existente, acaoSugerida: "ATUALIZAR_CLIENTE" });
  }
  const customer = store.createCustomer({ organizationId, nome, tipo, cnpj });
  const lead = store.createLead({ organizationId, customerId: customer.id, origem: "prospector", status: "novo" });
  res.status(201).json({ duplicado: false, customer, lead });
});
