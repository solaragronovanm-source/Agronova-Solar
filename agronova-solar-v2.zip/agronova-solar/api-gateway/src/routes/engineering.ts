import { Router } from "express";
import { store } from "../repositories/store";
import { calculateSolarGeneration, sizeBess, buildScenarios, LoadReading } from "@agronova/engineering-engine";
import { explainSolar, explainBess, explainScenarios } from "@agronova/ai-copilot";

export const engineeringRouter = Router();

function loadReadingsFor(energyAccountId: string): LoadReading[] {
  const rows = store.loadReadings.get(energyAccountId);
  if (!rows || rows.length === 0) {
    throw Object.assign(new Error("Sem memória de massa importada para esta conta de energia — importe via POST /energy-accounts/:id/load-profile antes de calcular."), { status: 422 });
  }
  return rows.map((r) => ({ data: r.data, hora: r.hora, consumoKwh: r.consumoKwh, demandaKw: r.demandaKw, posto: r.posto as any }));
}

engineeringRouter.post("/solar", (req, res) => {
  try {
    const { energyAccountId, potenciaKwp, irradiacaoMediaKwhM2Dia, performanceRatio } = req.body ?? {};
    if (!energyAccountId || !potenciaKwp || !irradiacaoMediaKwhM2Dia) {
      return res.status(400).json({ error: "energyAccountId, potenciaKwp e irradiacaoMediaKwhM2Dia são obrigatórios" });
    }
    const loadReadings = loadReadingsFor(energyAccountId);
    const result = calculateSolarGeneration({ loadReadings, potenciaKwp, irradiacaoMediaKwhM2Dia, performanceRatio });
    res.json({ result, explicacao: explainSolar(result) });
  } catch (err: any) {
    res.status(err.status ?? 500).json({ error: err.message });
  }
});

engineeringRouter.post("/bess", (req, res) => {
  try {
    const { energyAccountId, aplicacao, demandaContratadaKw, demandaMedidaMaximaKw, horasBackupDesejadas, solarGeneration } = req.body ?? {};
    if (!energyAccountId || !aplicacao) {
      return res.status(400).json({ error: "energyAccountId e aplicacao são obrigatórios" });
    }
    const loadReadings = loadReadingsFor(energyAccountId);
    const result = sizeBess({ loadReadings, aplicacao, demandaContratadaKw, demandaMedidaMaximaKw, horasBackupDesejadas, solarGeneration });
    res.json({ result, explicacao: explainBess(result) });
  } catch (err: any) {
    res.status(err.status ?? 500).json({ error: err.message });
  }
});

engineeringRouter.post("/scenarios", (req, res) => {
  try {
    const {
      energyAccountId, tariff, potenciaKwpProposta, irradiacaoMediaKwhM2Dia,
      demandaContratadaKw, demandaMedidaMaximaKw, capexPorKwpReais, capexPorKwhBessReais,
    } = req.body ?? {};
    if (!energyAccountId || !tariff || !potenciaKwpProposta || !irradiacaoMediaKwhM2Dia || !capexPorKwpReais || !capexPorKwhBessReais) {
      return res.status(400).json({
        error: "energyAccountId, tariff, potenciaKwpProposta, irradiacaoMediaKwhM2Dia, capexPorKwpReais e capexPorKwhBessReais são obrigatórios",
      });
    }
    const loadReadings = loadReadingsFor(energyAccountId);
    const scenarios = buildScenarios({
      loadReadings, tariff, potenciaKwpProposta, irradiacaoMediaKwhM2Dia,
      demandaContratadaKw, demandaMedidaMaximaKw, capexPorKwpReais, capexPorKwhBessReais,
    });
    res.json({ scenarios, explicacao: explainScenarios(scenarios) });
  } catch (err: any) {
    res.status(err.status ?? 500).json({ error: err.message });
  }
});
