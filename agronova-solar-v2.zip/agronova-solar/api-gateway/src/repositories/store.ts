import { randomUUID } from "node:crypto";

/**
 * Repositório em memória para o MVP. A entidade e as colunas espelham `db/schema.sql`
 * (PostgreSQL, canônico para produção) — trocar esta camada por Prisma/Knex apontando para
 * Postgres é o próximo passo real de implementação, sem mudar o formato dos dados.
 */
export interface Customer {
  id: string;
  organizationId: string;
  nome: string;
  tipo: "residencial" | "empresa" | "rural";
  cnpj?: string;
  createdAt: string;
}

export interface Lead {
  id: string;
  organizationId: string;
  customerId: string;
  origem: string;
  prospectScore?: number;
  leadScore?: number;
  status: string;
  createdAt: string;
}

export interface Opportunity {
  id: string;
  organizationId: string;
  customerId: string;
  product: string;
  origemCrossSell: boolean;
  status: "aberta" | "parada" | "ganha" | "perdida";
  valor?: number;
  createdAt: string;
}

export interface EnergyAccount {
  id: string;
  customerId: string;
  unidadeConsumidora: string;
  grupo: "A" | "B";
  modalidade?: string;
  mercado: "cativo" | "livre";
}

export interface LoadReadingRow {
  id: string;
  energyAccountId: string;
  data: string;
  hora: number;
  consumoKwh: number;
  demandaKw?: number;
  posto?: string;
}

export interface Task {
  id: string;
  organizationId: string;
  customerId?: string;
  titulo: string;
  status: "pendente" | "concluida" | "atrasada";
  createdAt: string;
}

class InMemoryStore {
  customers = new Map<string, Customer>();
  leads = new Map<string, Lead>();
  opportunities = new Map<string, Opportunity>();
  energyAccounts = new Map<string, EnergyAccount>();
  loadReadings = new Map<string, LoadReadingRow[]>(); // keyed by energyAccountId
  tasks = new Map<string, Task>();

  createCustomer(input: Omit<Customer, "id" | "createdAt">): Customer {
    const customer: Customer = { ...input, id: randomUUID(), createdAt: new Date().toISOString() };
    this.customers.set(customer.id, customer);
    return customer;
  }

  findCustomerByCnpj(cnpj: string): Customer | undefined {
    return [...this.customers.values()].find((c) => c.cnpj === cnpj);
  }

  createLead(input: Omit<Lead, "id" | "createdAt">): Lead {
    const lead: Lead = { ...input, id: randomUUID(), createdAt: new Date().toISOString() };
    this.leads.set(lead.id, lead);
    return lead;
  }

  createOpportunity(input: Omit<Opportunity, "id" | "createdAt">): Opportunity {
    const opp: Opportunity = { ...input, id: randomUUID(), createdAt: new Date().toISOString() };
    this.opportunities.set(opp.id, opp);
    return opp;
  }

  createEnergyAccount(input: Omit<EnergyAccount, "id">): EnergyAccount {
    const acc: EnergyAccount = { ...input, id: randomUUID() };
    this.energyAccounts.set(acc.id, acc);
    this.loadReadings.set(acc.id, []);
    return acc;
  }

  addLoadReadings(energyAccountId: string, readings: Omit<LoadReadingRow, "id" | "energyAccountId">[]) {
    const existentes = this.loadReadings.get(energyAccountId) ?? [];
    const novas = readings.map((r) => ({ ...r, id: randomUUID(), energyAccountId }));
    this.loadReadings.set(energyAccountId, [...existentes, ...novas]);
    return novas;
  }

  createTask(input: Omit<Task, "id" | "createdAt">): Task {
    const task: Task = { ...input, id: randomUUID(), createdAt: new Date().toISOString() };
    this.tasks.set(task.id, task);
    return task;
  }
}

// Singleton — MVP de processo único. Produção usa Postgres (db/schema.sql) via services/*.
export const store = new InMemoryStore();
