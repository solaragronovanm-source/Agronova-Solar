import express from "express";
import cors from "cors";
import { customersRouter } from "./routes/customers";
import { opportunitiesRouter } from "./routes/opportunities";
import { energyAccountsRouter } from "./routes/energyAccounts";
import { engineeringRouter } from "./routes/engineering";

const app = express();
app.use(cors());
app.use(express.json({ limit: "5mb" }));

app.get("/api/v1/health", (req, res) => res.json({ status: "ok", service: "agronova-api-gateway" }));

app.use("/api/v1/customers", customersRouter);
app.use("/api/v1/opportunities", opportunitiesRouter);
app.use("/api/v1/energy-accounts", energyAccountsRouter);
app.use("/api/v1/engineering", engineeringRouter);

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
if (process.env.NODE_ENV !== "test") {
  app.listen(PORT, () => console.log(`Agronova API Gateway ouvindo em http://localhost:${PORT}`));
}

export { app };
