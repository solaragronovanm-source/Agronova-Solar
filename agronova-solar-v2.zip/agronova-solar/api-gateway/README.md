# API Gateway

Camada de entrada versionada `/api/v1`. Roteia para os serviços de domínio
(`services/*`). Operações pesadas (OCR, enriquecimento, importação de memória de massa,
simulação, otimização, scoring, atualização tarifária/catálogo) devem ser assíncronas e usar
idempotency keys.

Endpoints mínimos (§26): customers, prospects, leads, opportunities, proposals, energy-bills
(+ extract/validate), load-profiles (+ analyze), tariffs, distributors, engineering/* (solar,
bess, hybrid, transformer, ev, backup, scenarios + results), financial/scenarios,
technology/catalog, technology/compatibility, scores, risk, nba, cross-sell, tasks, messages,
automations, events.

Stack de implementação: não definida ainda no Prompt Master — decisão em aberto.

Status: stub — nenhuma lógica implementada.
