# Prospector Intelligence

Encontra empresas por CNPJ, CNAE, segmento, localização, consumo potencial, Mercado Livre,
porte, demanda, atividade, infraestrutura, potencial solar/BESS.

Score 0–100: Energy Potential, Commercial Fit, Data Quality, Segment Fit, Financial Potential,
Urgency, Expansion Potential.

Fluxo: lead → diagnóstico → engineering opportunity.

**Fluxo de captura (complemento preservado):**
`CAPTURAR NO CRM` → verificar duplicidade por CNPJ → localizar Cliente 360° existente →
enriquecer dados → criar/atualizar lead → associar dados energéticos → gerar Prospect Score →
disponibilizar para qualificação. CNPJ já existente → oferecer `ATUALIZAR CLIENTE`, nunca duplicar.

Ao buscar decisor (nome do sócio + empresa + cidade + segmento), nunca assumir automaticamente
que uma pessoa encontrada é o decisor correto — sinalizar
"⚠️ Possível homônimo — confirme a identidade antes de abordar" quando houver ambiguidade.

**Endpoints previstos (§26):** /api/v1/prospects.

Status: stub — nenhuma lógica implementada.
