# Engineering Calculation Engine

Motor determinístico e independente da IA. A IA (ai-copilot) NUNCA calcula — apenas
interpreta o que este motor produz.

Fluxo obrigatório (§7):
INPUT VALIDATION → UNIT NORMALIZATION → DATA QUALITY → LOAD MODEL → TARIFF MODEL →
SOLAR MODEL → BESS MODEL → GRID MODEL → TRANSFORMER MODEL → BACKUP MODEL →
HYBRID SIMULATION → FINANCIAL MODEL → SCENARIO ENGINE → OPTIMIZATION →
ENGINEERING REPORT → AI INTERPRETATION.

Unidades obrigatoriamente explícitas, sem conversão implícita: W/kW/MW; Wh/kWh/MWh;
Wp/kWp/MWp; kVA/MVA; BESS kW (potência) ≠ BESS kWh (energia); R$/kWh; R$/MWh; A; V; Hz; PF.

Toda execução registra: engine_version, input_hash, output_hash, formula_id + version +
source + assumptions por fórmula usada.

Submódulos: `solar/`, `bess/`, `financial/`, `scenario/`, `optimization/`.

**Endpoints previstos (§26):** /api/v1/engineering/solar, /bess, /hybrid, /transformer, /ev,
/backup, /scenarios, /scenarios/{id}/results. Simulação e otimização são assíncronas.

Status: stub — nenhuma lógica implementada.
