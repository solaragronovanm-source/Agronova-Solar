# Solar Engine

Dimensiona: potência DC/AC, relação DC/AC, módulos, strings, inversores, geração, perdas,
clipping, orientação, inclinação, temperatura, disponibilidade, localização, irradiância,
autoconsumo, excedente, geração horária/mensal/anual, expansão futura.

Tecnologias suportadas: string inverter, microinverter, hybrid inverter, AC-coupled,
DC-coupled quando aplicável.

Status: stub.
