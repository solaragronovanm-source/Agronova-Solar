# BESS Engine — núcleo estratégico

Diferencia obrigatoriamente BESS POWER (kW/MW) de BESS ENERGY (kWh/MWh).

Calcula independentemente: potência PCS, capacidade energética, C-rate, SOC mínimo/máximo,
DoD, eficiência (ida/volta/carga/descarga), ciclos, degradação, temperatura, vida útil,
disponibilidade, reserva, potência/duração de carga e descarga, ponto de conexão.

Aplicações: peak shaving, redução de demanda, arbitragem ponta/fora ponta, solar shifting,
solar → BESS, backup, microgrid, resiliência, redução de ultrapassagem.

Dimensiona: BESS mínimo, ótimo, conservador, para expansão futura. Simula SOC hora a hora.

**Verificação de demanda (complemento preservado):** antes de dimensionar BESS para clientes
com demanda contratada, comparar demanda contratada × demanda medida (via OCR) e identificar
ultrapassagem, folga, picos e risco — isso alimenta o dimensionamento. Nunca recomendar
Storage apenas porque o cliente "consome muito", sempre com essa verificação como evidência.

Status: stub.
