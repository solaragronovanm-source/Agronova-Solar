import { createHash } from "node:crypto";

/** Hash determinístico de qualquer input/output do Engineering Engine (rastreabilidade — §7, §30). */
export function stableHash(value: unknown): string {
  const json = JSON.stringify(value, Object.keys(value as object).sort?.() ?? undefined);
  return createHash("sha256").update(json).digest("hex").slice(0, 16);
}

export const ENGINE_VERSION = "engineering-engine@0.1.0";
