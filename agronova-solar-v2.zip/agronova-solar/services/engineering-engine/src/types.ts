// Tipos compartilhados do Engineering Calculation Engine.
// Unidades sempre explícitas no nome do campo — nunca conversão implícita (Prompt Master §7).

export interface LoadReading {
  data: string; // ISO date (YYYY-MM-DD)
  hora: number; // 0-23
  consumoKwh: number;
  demandaKw?: number;
  posto?: "ponta" | "fora_ponta" | "intermediario";
  diaUtil?: boolean;
}

export interface TariffInput {
  teReaisPorKwh: number; // Tarifa de Energia
  tusdReaisPorKwh: number; // Tarifa de Uso do Sistema de Distribuição
  demandaContratadaKw?: number;
  precoDemandaReaisPorKw?: number;
}

export interface SolarInput {
  loadReadings: LoadReading[];
  potenciaKwp: number;
  irradiacaoMediaKwhM2Dia: number; // fornecida pelo usuário/base local — nunca assumida
  performanceRatio?: number; // default 0.8 se não informado, mas sempre explícito no output
}

export interface SolarHourlyGeneration {
  data: string;
  hora: number;
  geracaoKwh: number;
}

export interface SolarResult {
  engineVersion: string;
  inputHash: string;
  geracaoHoraria: SolarHourlyGeneration[];
  geracaoAnualEstimadaKwh: number;
  autoconsumoKwh: number;
  excedenteKwh: number;
  premissas: Record<string, number | string>;
}

export interface BessInput {
  loadReadings: LoadReading[];
  solarGeneration?: SolarHourlyGeneration[];
  aplicacao: "peak_shaving" | "arbitragem" | "solar_shifting" | "backup";
  demandaContratadaKw?: number;
  demandaMedidaMaximaKw?: number;
  socMinPct?: number; // default 10
  socMaxPct?: number; // default 95
  eficienciaRoundTripPct?: number; // default 90
  horasBackupDesejadas?: number; // apenas para aplicação backup
}

export interface BessSocPoint {
  data: string;
  hora: number;
  socPct: number;
  potenciaCargaKw: number;
  potenciaDescargaKw: number;
}

export interface BessResult {
  engineVersion: string;
  inputHash: string;
  potenciaRecomendadaKw: number;
  capacidadeRecomendadaKwh: number;
  socHoraHora: BessSocPoint[];
  justificativa: string;
  evidencias: string[];
  premissas: Record<string, number | string>;
}

export interface FinancialInput {
  capexReais: number;
  economiaMensalReais: number[]; // 12 a 300 posições (meses)
  opexMensalReais?: number;
  taxaDescontoAoMesPct?: number; // default 1%
  degradacaoAnualPct?: number; // default 0.5% (solar) — informar por cenário
}

export interface FinancialResult {
  paybackSimplesMeses: number | null;
  paybackDescontadoMeses: number | null;
  tirAoMesPct: number | null;
  vplReais: number;
  premissas: Record<string, number | string>;
}

export interface ScenarioDefinition {
  codigo: string; // S0..S10
  nome: string;
  incluiSolar: boolean;
  incluiBess: boolean;
}

export interface ScenarioResult {
  codigo: string;
  nome: string;
  capexReais: number;
  economiaAnualReais: number;
  financeiro: FinancialResult;
  solar?: SolarResult;
  bess?: BessResult;
}
