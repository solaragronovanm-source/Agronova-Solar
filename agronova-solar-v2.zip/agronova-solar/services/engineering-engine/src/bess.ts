import { BessInput, BessResult, BessSocPoint } from "./types";
import { stableHash, ENGINE_VERSION } from "./hash";

const DEFAULT_SOC_MIN = 10;
const DEFAULT_SOC_MAX = 95;
const DEFAULT_ROUND_TRIP_EFFICIENCY = 90;

/**
 * BESS POWER (kW) e BESS ENERGY (kWh) são sempre calculados e reportados separadamente —
 * nunca confundidos (Prompt Master §9, regra crítica do BESS Engine).
 *
 * Esta função NÃO recomenda storage apenas porque o cliente "consome muito": o dimensionamento
 * é derivado de uma verificação explícita (demanda contratada × medida para peak_shaving, ou
 * excedente solar real para solar_shifting, ou carga crítica informada para backup).
 */
export function sizeBess(input: BessInput): BessResult {
  const socMin = input.socMinPct ?? DEFAULT_SOC_MIN;
  const socMax = input.socMaxPct ?? DEFAULT_SOC_MAX;
  const eficiencia = input.eficienciaRoundTripPct ?? DEFAULT_ROUND_TRIP_EFFICIENCY;
  const usableFraction = (socMax - socMin) / 100;

  let potenciaRecomendadaKw = 0;
  let capacidadeRecomendadaKwh = 0;
  const evidencias: string[] = [];
  let justificativa = "";

  if (input.aplicacao === "peak_shaving") {
    if (!input.demandaContratadaKw || !input.demandaMedidaMaximaKw) {
      throw new Error(
        "peak_shaving exige demandaContratadaKw e demandaMedidaMaximaKw — verificação de demanda contratada × medida " +
        "é obrigatória antes de dimensionar BESS para essa aplicação (complemento preservado do Prompt Master)."
      );
    }
    const ultrapassagemKw = Math.max(0, input.demandaMedidaMaximaKw - input.demandaContratadaKw);
    if (ultrapassagemKw === 0) {
      justificativa =
        "Demanda medida não ultrapassa a demanda contratada nos dados analisados — não há evidência técnica " +
        "para recomendar BESS por peak shaving neste momento.";
      evidencias.push(`demanda medida máxima (${input.demandaMedidaMaximaKw} kW) <= demanda contratada (${input.demandaContratadaKw} kW)`);
    } else {
      potenciaRecomendadaKw = Number(ultrapassagemKw.toFixed(1));
      const horasAcimaDoLimite = input.loadReadings.filter(
        (r) => (r.demandaKw ?? r.consumoKwh) > input.demandaContratadaKw!
      ).length;
      const horasPorDia = Math.max(1, horasAcimaDoLimite / Math.max(1, new Set(input.loadReadings.map((r) => r.data)).size));
      capacidadeRecomendadaKwh = Number(((potenciaRecomendadaKw * horasPorDia) / usableFraction).toFixed(1));
      justificativa =
        `Demanda medida ultrapassa a contratada em ${ultrapassagemKw.toFixed(1)} kW nos dados analisados. ` +
        `BESS dimensionado para cobrir essa ultrapassagem e evitar multa/contrato de demanda.`;
      evidencias.push(`ultrapassagem detectada: ${ultrapassagemKw.toFixed(1)} kW`, `horas/dia acima do limite: ${horasPorDia.toFixed(1)}`);
    }
  } else if (input.aplicacao === "backup") {
    if (!input.demandaMedidaMaximaKw || !input.horasBackupDesejadas) {
      throw new Error("backup exige demandaMedidaMaximaKw (carga crítica) e horasBackupDesejadas");
    }
    potenciaRecomendadaKw = input.demandaMedidaMaximaKw;
    capacidadeRecomendadaKwh = Number(
      ((input.demandaMedidaMaximaKw * input.horasBackupDesejadas) / usableFraction / (eficiencia / 100)).toFixed(1)
    );
    justificativa = `Dimensionado para sustentar carga crítica de ${input.demandaMedidaMaximaKw} kW por ${input.horasBackupDesejadas}h.`;
    evidencias.push(`carga crítica informada: ${input.demandaMedidaMaximaKw} kW`, `autonomia desejada: ${input.horasBackupDesejadas}h`);
  } else if (input.aplicacao === "solar_shifting" || input.aplicacao === "arbitragem") {
    if (!input.solarGeneration || input.solarGeneration.length === 0) {
      throw new Error("solar_shifting/arbitragem exigem solarGeneration (saída do Solar Engine)");
    }
    const excedentePorHora = new Map<string, number>();
    const consumoPorHora = new Map<string, number>();
    for (const r of input.loadReadings) consumoPorHora.set(`${r.data}|${r.hora}`, r.consumoKwh);
    for (const g of input.solarGeneration) {
      const consumo = consumoPorHora.get(`${g.data}|${g.hora}`) ?? 0;
      excedentePorHora.set(`${g.data}|${g.hora}`, Math.max(0, g.geracaoKwh - consumo));
    }
    const excedentesPorDia = new Map<string, number>();
    let picoExcedenteKw = 0;
    for (const [chave, valor] of excedentePorHora) {
      const [data] = chave.split("|");
      excedentesPorDia.set(data, (excedentesPorDia.get(data) ?? 0) + valor);
      if (valor > picoExcedenteKw) picoExcedenteKw = valor;
    }
    const mediaExcedenteDiarioKwh =
      [...excedentesPorDia.values()].reduce((a, b) => a + b, 0) / Math.max(1, excedentesPorDia.size);

    potenciaRecomendadaKw = Number(picoExcedenteKw.toFixed(1));
    capacidadeRecomendadaKwh = Number((mediaExcedenteDiarioKwh / usableFraction).toFixed(1));
    justificativa =
      `Dimensionado para armazenar o excedente solar médio diário (${mediaExcedenteDiarioKwh.toFixed(1)} kWh) ` +
      `e deslocá-lo para horários de maior custo/demanda.`;
    evidencias.push(`pico de excedente solar horário: ${picoExcedenteKw.toFixed(1)} kW`, `excedente médio diário: ${mediaExcedenteDiarioKwh.toFixed(1)} kWh`);
  }

  const socHoraHora: BessSocPoint[] = simulateSoc(input, potenciaRecomendadaKw, capacidadeRecomendadaKwh, socMin, socMax);

  return {
    engineVersion: ENGINE_VERSION,
    inputHash: stableHash({ aplicacao: input.aplicacao, demandaContratadaKw: input.demandaContratadaKw, demandaMedidaMaximaKw: input.demandaMedidaMaximaKw, nReadings: input.loadReadings.length }),
    potenciaRecomendadaKw,
    capacidadeRecomendadaKwh,
    socHoraHora,
    justificativa,
    evidencias,
    premissas: { socMinPct: socMin, socMaxPct: socMax, eficienciaRoundTripPct: eficiencia },
  };
}

/** Simulação simplificada de SOC hora a hora para as primeiras 24h da amostra (demonstração). */
function simulateSoc(
  input: BessInput,
  potenciaKw: number,
  capacidadeKwh: number,
  socMin: number,
  socMax: number
): BessSocPoint[] {
  if (capacidadeKwh <= 0) return [];
  const primeiroDia = input.loadReadings[0]?.data;
  const leiturasDoDia = input.loadReadings.filter((r) => r.data === primeiroDia).sort((a, b) => a.hora - b.hora);

  let socPct = socMax;
  const pontos: BessSocPoint[] = [];
  for (const leitura of leiturasDoDia) {
    let potenciaCargaKw = 0;
    let potenciaDescargaKw = 0;

    if (input.aplicacao === "peak_shaving" && input.demandaContratadaKw) {
      const demanda = leitura.demandaKw ?? leitura.consumoKwh;
      if (demanda > input.demandaContratadaKw && socPct > socMin) {
        potenciaDescargaKw = Math.min(potenciaKw, demanda - input.demandaContratadaKw);
        socPct -= (potenciaDescargaKw / capacidadeKwh) * 100;
      } else if (socPct < socMax) {
        potenciaCargaKw = Math.min(potenciaKw, (socMax - socPct) * capacidadeKwh / 100);
        socPct += (potenciaCargaKw / capacidadeKwh) * 100;
      }
    }
    socPct = Math.max(socMin, Math.min(socMax, socPct));
    pontos.push({ data: leitura.data, hora: leitura.hora, socPct: Number(socPct.toFixed(1)), potenciaCargaKw: Number(potenciaCargaKw.toFixed(1)), potenciaDescargaKw: Number(potenciaDescargaKw.toFixed(1)) });
  }
  return pontos;
}
