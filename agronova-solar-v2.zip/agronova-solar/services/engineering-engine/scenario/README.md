# Scenario Engine

Cenários versionados por cliente: S0 (atual), S1 (Solar), S2 (BESS), S3 (Solar+BESS),
S4 (Solar+BESS+expansão), S5 (BESS peak shaving), S6 (BESS arbitragem), S7 (backup),
S8 (Solar+BESS+EV), S9 (retrofit), S10 (híbrido customizado).

Mostra lado a lado: CAPEX, OPEX, economia, demanda, energia comprada/excedente, SOC, ciclos,
payback, TIR, VPL, risco, resiliência, CO2 evitado quando aplicável.

Status: stub.
