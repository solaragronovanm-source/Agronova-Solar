# Optimization Engine

Testa combinações de Solar (kWp) × BESS (kW/kWh) dentro dos limites técnicos.

Objetivos multiobjetivo configuráveis: technical_fit, financial_return, energy_savings,
resilience, future_expansion, risk. Pesos configuráveis por projeto.

Ranges de referência para iteração automática (parametrizáveis): Solar 50–150 kWp; BESS
capacidade 100–500 kWh; BESS potência 100 kW–2 MW.

**Nunca escolher automaticamente uma solução apenas porque possui menor payback.**

Status: stub.
