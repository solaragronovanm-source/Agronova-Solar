# Financial Engine

Calcula: CAPEX, OPEX, financiamento, juros, CDI, leasing, inflação, degradação, reajuste
tarifário, manutenção, substituição, vida útil.

Indicadores: payback simples/descontado, ROI, TIR/IRR, VPL/NPV, LCOE quando aplicável, custo
evitado, economia anual/acumulada.

Compara: CAPEX próprio, financiamento, leasing, BESS como serviço, PPA, modelos híbridos.

**Versionamento por cenário (complemento preservado):** cada conjunto de premissas
financeiras deve ser nomeado e versionado (ex.: "Cenário A — taxa 1,2% a.m.", "Cenário B —
leasing", "Cenário C — capital próprio") para comparação lado a lado sem perder histórico.

Status: stub.
