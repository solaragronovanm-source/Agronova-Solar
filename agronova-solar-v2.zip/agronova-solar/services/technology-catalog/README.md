# Technology Catalog

Banco de tecnologias e equipamentos reais do mercado brasileiro. Nunca gravar especificações
como verdades permanentes — todo item carrega fonte, data, versão, disponibilidade, confiança.

Catálogo inicial de fabricantes (não é recomendação automática, apenas cadastro de mercado):

- BESS: WEG, Moura, UCB Power, BYD, CATL, Sungrow, Huawei, Jinko ESS, Pylontech, Solis,
  GoodWe, Tesla, Ingeteam, GE Vernova.
- Solar: WEG, Huawei, Sungrow, Growatt, Solis, GoodWe, BYD, Canadian Solar, Jinko Solar,
  JA Solar, Astronergy, DMEGC, Trina Solar, LONGi, Risen.

Technology Compatibility Engine verifica: potência, tensão, PCS, inversor, EMS,
transformador, proteção, comunicação, temperatura, aplicação, certificações, espaço físico,
C-rate, garantia, ciclos, disponibilidade.

**Endpoints previstos (§26):** /api/v1/technology/catalog, /technology/compatibility.

Status: stub — nenhuma lógica implementada.
