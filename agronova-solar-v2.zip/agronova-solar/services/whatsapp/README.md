# WhatsApp

Botões: ABRIR WHATSAPP, COPIAR MENSAGEM, ENVIAR WHATSAPP, AGENDAR WHATSAPP, MARCAR COMO FEITO.

IA gera mensagem contextualizada (via ai-copilot). Envio automático exige autorização e
permissão explícitas, com auditoria completa (abertura, cópia, envio, falha, agendamento).

Integração inexistente = status `NOT_CONNECTED`, nunca apresentada como conectada.

Status: stub — nenhuma lógica implementada.
