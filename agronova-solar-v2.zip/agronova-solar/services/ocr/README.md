# OCR / Leitor de Conta

Extrai da conta de energia: UC, titular, CNPJ/CPF, distribuidora, grupo, subgrupo, classe,
tensão, modalidade, consumo (total/ponta/fora ponta), demanda contratada/medida, energia
injetada, créditos, tarifas (TE/TUSD), impostos, encargos, valor total, histórico.

Cada campo extraído carrega: value, confidence, source, extraction_version, status
(EXTRACTED | REQUIRES_REVIEW | VALIDATED).

**Regra crítica:** dado crítico de baixa confiança não entra em cálculo definitivo. Exibir
sempre tela de confirmação humana ("Identificamos estes dados. Confirme antes de calcular.")
antes de qualquer dado extraído alimentar o Engineering Engine.

**Endpoints previstos (§26):** /api/v1/energy-bills/{id}/extract, /energy-bills/{id}/validate.
Operação assíncrona.

Status: stub — nenhuma lógica implementada.
