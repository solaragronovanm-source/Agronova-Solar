# Energy Digital Twin

Modelo digital da unidade consumidora. Entradas: conta de energia, memória de massa,
telemetria, medidor, dados do Mercado Livre, perfil operacional, localização, equipamentos,
horário de funcionamento, produção, expansão futura.

Calcula: carga horária/média/mínima/máxima, fator de carga, demanda, pico, perfil de
ponta/fora ponta, dias úteis/finais de semana, sazonalidade, curva de duração, energia
anual/mensal, sobreposição carga/solar, excedente, necessidade de BESS, oportunidades de
redução de demanda.

**Regra crítica:** a série original (`load_readings`) é imutável. Agregações são sempre
derivadas e recalculáveis — nunca substituir série horária real por média mensal.

**Endpoints previstos (§26):** /api/v1/load-profiles, /load-profiles/{id}/analyze.

Status: stub — nenhuma lógica implementada.
