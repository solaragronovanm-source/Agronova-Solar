import automationRules from "../../../config/automation-rules.json" with { type: "json" };
import crossSellMap from "../../../config/product-cross-sell-map.json" with { type: "json" };

export interface DomainEvent {
  eventType: string;
  organizationId: string;
  aggregateType: string;
  aggregateId: string;
  occurredAt: string;
  payload: Record<string, unknown>;
}

export interface AutomationExecution {
  ruleId: string;
  name: string;
  status: "COMPLETED" | "WAITING_APPROVAL" | "SKIPPED";
  reason: string;
}

/**
 * Casa um evento contra as regras AUT-001..AUT-015. Implementação mínima do MVP: casa por
 * event_type e reporta se a regra exige aprovação humana antes de executar a ação — nunca
 * cria oportunidade sozinha quando approval_required é true (Prompt Master §17/§22).
 */
export function matchAutomationRules(event: DomainEvent): AutomationExecution[] {
  const regras = (automationRules as any).rules as Array<{
    rule_id: string;
    name: string;
    event: string;
    approval_required: boolean;
  }>;

  return regras
    .filter((r) => r.event === event.eventType)
    .map((r) => ({
      ruleId: r.rule_id,
      name: r.name,
      status: r.approval_required ? "WAITING_APPROVAL" : "COMPLETED",
      reason: r.approval_required
        ? "Regra exige aprovação humana antes de criar oportunidade/ação."
        : "Condições mínimas satisfeitas (event match) — MVP não avalia 'conditions' detalhadas ainda.",
    }));
}

export interface CrossSellSuggestion {
  produtoOrigem: string;
  produtosSugeridos: string[];
  estado: "DETECTED" | "WAITING_APPROVAL";
}

/** Nunca cria oportunidade sozinho — sempre retorna sugestão aguardando aprovação humana. */
export function suggestCrossSell(produtoFechado: string): CrossSellSuggestion {
  const map = (crossSellMap as any).cross_sell_map as Record<string, string[]>;
  const sugestoes = map[produtoFechado] ?? [];
  return {
    produtoOrigem: produtoFechado,
    produtosSugeridos: sugestoes.filter((s) => !s.startsWith("*")),
    estado: "WAITING_APPROVAL",
  };
}
