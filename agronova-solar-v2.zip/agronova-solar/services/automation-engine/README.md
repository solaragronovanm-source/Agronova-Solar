# Automation Engine

Fluxo: EVENTO → REGRA → CONDIÇÕES → IDEMPOTÊNCIA → AÇÃO → LOG → RESULTADO.

Estados: PENDING, PROCESSING, COMPLETED, FAILED, SKIPPED, WAITING_APPROVAL.

Regras AUT-001 a AUT-015 definidas em `../../config/automation-rules.json`.

**Nenhuma automação cria oportunidade sem regra explícita e controle humano.**

**Endpoints previstos (§26):** /api/v1/automations, /automations/history, /events.

Status: stub — nenhuma lógica implementada.
