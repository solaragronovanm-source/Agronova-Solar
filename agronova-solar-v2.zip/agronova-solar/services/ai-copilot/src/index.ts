import type { BessResult, ScenarioResult, SolarResult } from "@agronova/engineering-engine";

/**
 * AI Copilot — explica o que o Engineering Engine calculou. NUNCA calcula por conta própria:
 * todo número aqui vem direto dos objetos SolarResult/BessResult/ScenarioResult (Prompt Master §12/§19).
 *
 * Implementação determinística (sem chamada a LLM) para o MVP: monta o formato obrigatório
 * DECISÃO / POR QUÊ / DADOS / PREMISSAS / CONFIANÇA / RISCOS / PRÓXIMA AÇÃO a partir dos
 * campos que o engine já produziu. Um LLM pode ser plugado depois para reescrever o texto de
 * forma mais natural, mas os NÚMEROS usados devem continuar vindo exclusivamente daqui.
 */
export interface StructuredExplanation {
  decisao: string;
  porQue: string;
  dados: Record<string, unknown>;
  premissas: Record<string, unknown>;
  confianca: string;
  riscos: string[];
  proximaAcao: string;
}

export function explainSolar(result: SolarResult): StructuredExplanation {
  return {
    decisao: `Sistema solar estimado em ${result.geracaoAnualEstimadaKwh.toLocaleString("pt-BR")} kWh/ano.`,
    porQue: `Autoconsumo estimado de ${result.autoconsumoKwh} kWh e excedente de ${result.excedenteKwh} kWh na amostra analisada.`,
    dados: { geracaoAnualEstimadaKwh: result.geracaoAnualEstimadaKwh, autoconsumoKwh: result.autoconsumoKwh, excedenteKwh: result.excedenteKwh },
    premissas: result.premissas,
    confianca: result.premissas.irradiacaoMediaKwhM2Dia ? "alta — irradiação real informada" : "insuficiente",
    riscos: result.excedenteKwh > result.autoconsumoKwh
      ? ["Excedente maior que o autoconsumo — avaliar redimensionamento ou compensação/créditos."]
      : [],
    proximaAcao: "Apresentar cenário Solar (S1) ao cliente e comparar com Solar+BESS se houver ultrapassagem de demanda.",
  };
}

export function explainBess(result: BessResult): StructuredExplanation {
  const semRecomendacao = result.potenciaRecomendadaKw === 0;
  return {
    decisao: semRecomendacao
      ? "Nenhum BESS recomendado no momento."
      : `BESS recomendado: ${result.potenciaRecomendadaKw} kW / ${result.capacidadeRecomendadaKwh} kWh.`,
    porQue: result.justificativa,
    dados: { potenciaRecomendadaKw: result.potenciaRecomendadaKw, capacidadeRecomendadaKwh: result.capacidadeRecomendadaKwh, evidencias: result.evidencias },
    premissas: result.premissas,
    confianca: result.evidencias.length > 0 ? "alta — baseada em verificação de demanda/curva real" : "insuficiente",
    riscos: semRecomendacao ? [] : ["Validar viabilidade elétrica (PCS, ponto de conexão, espaço físico) com engenharia antes de propor."],
    proximaAcao: semRecomendacao
      ? "Não avançar com proposta de Storage sem nova evidência técnica."
      : "Selecionar tecnologia compatível no Technology Catalog e gerar proposta financeira.",
  };
}

export function explainScenarios(scenarios: ScenarioResult[]): StructuredExplanation {
  const linhas = scenarios.map(
    (s) => `${s.codigo} (${s.nome}): CAPEX R$ ${s.capexReais.toLocaleString("pt-BR")}, payback simples ${s.financeiro.paybackSimplesMeses ?? "não atingido no horizonte"} meses`
  );
  return {
    decisao: `${scenarios.length} cenário(s) calculado(s) e apresentados lado a lado — nenhum foi escolhido automaticamente.`,
    porQue: "Prompt Master exige que a decisão final entre cenários seja humana, nunca automática pelo menor payback.",
    dados: { cenarios: linhas },
    premissas: { horizonteConsiderado: "ver premissas de cada cenário individualmente" },
    confianca: "depende dos dados de entrada de cada cenário (ver campo premissas de cada um)",
    riscos: [],
    proximaAcao: "Consultor apresenta os cenários ao cliente e conduz a qualificação humanizada para decidir com ele.",
  };
}
