# AI Energy Copilot

A IA explica o cálculo — nunca o inventa. IA interpreta; o Engineering Engine calcula.

Perguntas que deve responder: por que esse BESS foi dimensionado; por que 1 MW e não
500 kW; quantas horas de autonomia; qual o impacto da ponta; quanto reduz a demanda; quanto
da energia solar será armazenada; qual o pior dia; qual o melhor cenário; o que acontece se
o cliente aumentar a produção; qual tecnologia atende melhor; qual o risco; o que falta para
fechar o cálculo.

Formato obrigatório de toda recomendação: DECISÃO, POR QUÊ, DADOS UTILIZADOS, PREMISSAS,
CÁLCULO, RESULTADO, CONFIANÇA, RISCOS, PRÓXIMA AÇÃO.

**Qualificação comercial (complemento preservado):** máximo 3–4 perguntas centrais (o que
motivou o contato agora; qual o principal problema hoje; já possui solar e é
residência/empresa/propriedade rural; solicitar conta ou memória de massa). Loop iterativo:
dado → hipótese → pergunta → nova informação → recálculo → novo cenário → validação →
recomendação.

Frase de posicionamento de referência para o cliente final: "Não estamos te oferecendo um
sistema porque você consome muito. Estamos analisando seu comportamento energético para
encontrar a configuração que faz sentido técnica e economicamente."

Status: stub — nenhuma lógica implementada.
