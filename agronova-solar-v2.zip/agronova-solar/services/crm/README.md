# CRM / Cliente 360

Entidades: organizations, users, teams, roles, permissions, customers, contacts, addresses,
documents, companies, enrichment, leads, opportunities, pipelines, products, product_rules,
proposals, proposal_items, proposal_versions, contracts, tasks, activities, appointments,
notes, messages, templates, deliveries, notifications.

Cliente 360 consolida: cadastro, CNPJ, CNAEs, contatos, documentos, histórico, propostas,
contratos, contas de energia, projetos, manutenção, limpeza, retrofit, storage, Grid Control,
interações, tarefas, scores, riscos e oportunidades.

**Endpoints previstos (§26):** /api/v1/customers, /leads, /opportunities, /proposals, /tasks.

Status: stub — nenhuma lógica implementada.
