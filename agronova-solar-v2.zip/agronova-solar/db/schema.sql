-- Agronova Intelligence — schema inicial
-- Gerado a partir do Prompt Master V2 (Engineering Platform).
-- Este arquivo fixa as ENTIDADES e RELACIONAMENTOS mínimos por módulo.
-- Tipos de dados e constraints devem ser refinados pela equipe de implementação;
-- o objetivo aqui é não deixar nenhuma entidade do prompt master de fora do esqueleto.
--
-- Convenções:
--   - Toda tabela de negócio carrega organization_id (multi-tenant).
--   - Toda execução de engenharia registra engine_version, input_hash, output_hash.
--   - Séries temporais (load_readings) nunca são sobrescritas — apenas agregações derivadas.

-- =========================================================
-- GOVERNANCE / CORE
-- =========================================================
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    email TEXT NOT NULL,
    name TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    name TEXT NOT NULL
);

CREATE TABLE permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_id UUID NOT NULL REFERENCES roles(id),
    module TEXT NOT NULL,
    action TEXT NOT NULL
);

CREATE TABLE teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    name TEXT NOT NULL
);

-- =========================================================
-- CRM / CLIENTE 360
-- =========================================================
CREATE TABLE companies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    cnpj TEXT,
    razao_social TEXT,
    nome_fantasia TEXT,
    situacao_cadastral TEXT,
    cnaes TEXT[],
    endereco JSONB,
    municipio TEXT,
    uf TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    company_id UUID REFERENCES companies(id),
    tipo TEXT CHECK (tipo IN ('residencial', 'empresa', 'rural')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE contacts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id),
    nome TEXT,
    cargo TEXT,
    telefone TEXT,
    email TEXT,
    is_decisor BOOLEAN DEFAULT false,
    homonimo_alerta BOOLEAN DEFAULT false
);

CREATE TABLE addresses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES customers(id),
    logradouro TEXT,
    municipio TEXT,
    uf TEXT,
    geolocation POINT
);

CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES customers(id),
    tipo TEXT,
    arquivo_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE enrichment (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID REFERENCES companies(id),
    fonte TEXT,
    confianca NUMERIC,
    data JSONB,
    captured_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE leads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    customer_id UUID REFERENCES customers(id),
    origem TEXT, -- 'prospector' | 'inbound' | 'indicacao' | ...
    prospect_score NUMERIC,
    lead_score NUMERIC,
    lead_score_version INT DEFAULT 1,
    status TEXT DEFAULT 'novo',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE pipelines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    nome TEXT
);

CREATE TABLE opportunities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    customer_id UUID REFERENCES customers(id),
    pipeline_id UUID REFERENCES pipelines(id),
    product TEXT, -- Solar | Limpeza | O&M | Retrofit | Storage | Cred | Invest | Grid Control | Agro
    origem_cross_sell BOOLEAN DEFAULT false,
    status TEXT DEFAULT 'aberta', -- aberta | parada | ganha | perdida
    valor NUMERIC,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome TEXT NOT NULL
);

CREATE TABLE product_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_from TEXT NOT NULL,
    product_to TEXT NOT NULL
);

CREATE TABLE proposals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    opportunity_id UUID NOT NULL REFERENCES opportunities(id),
    status TEXT DEFAULT 'rascunho', -- rascunho | enviada | expirando | expirada | aceita
    valor_total NUMERIC,
    enviada_em TIMESTAMPTZ,
    expira_em TIMESTAMPTZ
);

CREATE TABLE proposal_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proposal_id UUID NOT NULL REFERENCES proposals(id),
    descricao TEXT,
    quantidade NUMERIC,
    valor_unitario NUMERIC
);

CREATE TABLE proposal_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proposal_id UUID NOT NULL REFERENCES proposals(id),
    version INT NOT NULL,
    snapshot JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proposal_id UUID REFERENCES proposals(id),
    status TEXT DEFAULT 'ativo',
    expira_em TIMESTAMPTZ
);

CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    customer_id UUID REFERENCES customers(id),
    titulo TEXT,
    status TEXT DEFAULT 'pendente', -- pendente | concluida | atrasada
    due_at TIMESTAMPTZ
);

CREATE TABLE activities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES customers(id),
    tipo TEXT,
    descricao TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE appointments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES customers(id),
    inicio TIMESTAMPTZ,
    fim TIMESTAMPTZ
);

CREATE TABLE notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES customers(id),
    autor_id UUID REFERENCES users(id),
    texto TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES customers(id),
    canal TEXT DEFAULT 'whatsapp',
    conteudo TEXT,
    status TEXT DEFAULT 'gerada', -- gerada | enviada | falhou | agendada
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome TEXT,
    canal TEXT,
    conteudo TEXT
);

CREATE TABLE deliveries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID REFERENCES messages(id),
    status TEXT,
    delivered_at TIMESTAMPTZ
);

CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    conteudo TEXT,
    lida BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =========================================================
-- ENERGY / DIGITAL TWIN / MERCADO LIVRE
-- =========================================================
CREATE TABLE distributors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome TEXT NOT NULL,
    uf TEXT
);

CREATE TABLE tariff_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    distributor_id UUID NOT NULL REFERENCES distributors(id),
    subgrupo TEXT,
    modalidade TEXT,
    tensao TEXT,
    posto TEXT,
    te NUMERIC,
    tusd NUMERIC,
    demanda NUMERIC,
    vigencia_inicio DATE,
    vigencia_fim DATE,
    fonte TEXT,
    versao INT DEFAULT 1,
    confianca NUMERIC
);

CREATE TABLE tariff_components (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tariff_profile_id UUID NOT NULL REFERENCES tariff_profiles(id),
    componente TEXT,
    valor NUMERIC
);

CREATE TABLE energy_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id),
    distributor_id UUID REFERENCES distributors(id),
    unidade_consumidora TEXT,
    grupo TEXT, -- A | B
    subgrupo TEXT,
    modalidade TEXT,
    mercado TEXT DEFAULT 'cativo' -- cativo | livre (ACL)
);

CREATE TABLE energy_bills (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    energy_account_id UUID NOT NULL REFERENCES energy_accounts(id),
    arquivo_url TEXT,
    mes_referencia DATE,
    valor_total NUMERIC,
    status TEXT DEFAULT 'EXTRACTED', -- EXTRACTED | REQUIRES_REVIEW | VALIDATED
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE energy_bill_extractions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    energy_bill_id UUID NOT NULL REFERENCES energy_bills(id),
    campo TEXT NOT NULL,
    valor TEXT,
    confidence NUMERIC,
    source TEXT,
    extraction_version INT DEFAULT 1,
    status TEXT DEFAULT 'EXTRACTED'
);

CREATE TABLE load_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    energy_account_id UUID NOT NULL REFERENCES energy_accounts(id),
    origem TEXT, -- 'memoria_de_massa' | 'telemetria' | 'estimado'
    status TEXT DEFAULT 'imported' -- imported | validated
);

-- Série original imutável — nunca sobrescrever, apenas inserir novas leituras/versões.
CREATE TABLE load_readings (
    id BIGSERIAL PRIMARY KEY,
    load_profile_id UUID NOT NULL REFERENCES load_profiles(id),
    data DATE NOT NULL,
    hora SMALLINT NOT NULL,
    consumo_kwh NUMERIC,
    demanda_kw NUMERIC,
    posto TEXT, -- ponta | fora_ponta | intermediario
    dia_semana SMALLINT,
    dia_util BOOLEAN,
    fim_de_semana BOOLEAN,
    feriado BOOLEAN
);

-- Agregações derivadas (diária/semanal/mensal) — recalculáveis, não fonte de verdade.
CREATE TABLE load_aggregations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    load_profile_id UUID NOT NULL REFERENCES load_profiles(id),
    granularidade TEXT, -- diaria | semanal | mensal
    periodo DATE,
    consumo_medio NUMERIC,
    consumo_max NUMERIC,
    consumo_min NUMERIC,
    demanda_pico NUMERIC,
    fator_carga NUMERIC
);

CREATE TABLE energy_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    energy_account_id UUID NOT NULL REFERENCES energy_accounts(id),
    modelo JSONB,
    engine_version TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =========================================================
-- ENGINEERING CALCULATION ENGINE
-- =========================================================
CREATE TABLE engineering_calculations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    energy_account_id UUID NOT NULL REFERENCES energy_accounts(id),
    engine_version TEXT NOT NULL,
    input_hash TEXT NOT NULL,
    output_hash TEXT NOT NULL,
    status TEXT DEFAULT 'completed',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE engineering_inputs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    engineering_calculation_id UUID NOT NULL REFERENCES engineering_calculations(id),
    chave TEXT,
    valor JSONB
);

CREATE TABLE engineering_outputs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    engineering_calculation_id UUID NOT NULL REFERENCES engineering_calculations(id),
    chave TEXT,
    valor JSONB
);

CREATE TABLE engineering_assumptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    engineering_calculation_id UUID NOT NULL REFERENCES engineering_calculations(id),
    premissa TEXT,
    valor TEXT
);

CREATE TABLE formula_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    formula_id TEXT NOT NULL,
    version INT NOT NULL,
    source TEXT,
    valid_from DATE,
    valid_to DATE
);

CREATE TABLE regulatory_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome TEXT,
    codigo TEXT,
    versao TEXT,
    orgao TEXT,
    vigencia_inicio DATE,
    vigencia_fim DATE,
    fonte TEXT,
    tipo TEXT
);

-- Solar
CREATE TABLE solar_projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    energy_account_id UUID NOT NULL REFERENCES energy_accounts(id),
    potencia_dc_kwp NUMERIC,
    potencia_ac_kw NUMERIC,
    status TEXT DEFAULT 'draft'
);

CREATE TABLE solar_components (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    solar_project_id UUID NOT NULL REFERENCES solar_projects(id),
    tipo TEXT, -- modulo | inversor | string | microinverter
    tecnologia TEXT,
    quantidade INT
);

CREATE TABLE solar_scenarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    solar_project_id UUID NOT NULL REFERENCES solar_projects(id),
    nome TEXT,
    resultado JSONB
);

-- BESS
CREATE TABLE bess_projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    energy_account_id UUID NOT NULL REFERENCES energy_accounts(id),
    potencia_kw NUMERIC,   -- BESS POWER
    capacidade_kwh NUMERIC, -- BESS ENERGY
    soc_min NUMERIC,
    soc_max NUMERIC,
    dod NUMERIC,
    status TEXT DEFAULT 'draft'
);

CREATE TABLE bess_components (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bess_project_id UUID NOT NULL REFERENCES bess_projects(id),
    tipo TEXT, -- pcs | banco_baterias | ems
    fabricante TEXT,
    modelo TEXT
);

CREATE TABLE bess_scenarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bess_project_id UUID NOT NULL REFERENCES bess_projects(id),
    nome TEXT, -- minimo | otimo | conservador | expansao_futura
    aplicacao TEXT, -- peak_shaving | arbitragem | backup | solar_shifting | ...
    resultado JSONB
);

-- Cenários híbridos e simulação
CREATE TABLE hybrid_scenarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    energy_account_id UUID NOT NULL REFERENCES energy_accounts(id),
    codigo TEXT, -- S0..S10
    nome TEXT,
    resultado JSONB
);

CREATE TABLE simulation_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hybrid_scenario_id UUID REFERENCES hybrid_scenarios(id),
    engine_version TEXT,
    input_hash TEXT,
    output_hash TEXT,
    executed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE optimization_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    energy_account_id UUID NOT NULL REFERENCES energy_accounts(id),
    pesos JSONB, -- technical_fit, financial_return, energy_savings, resilience, future_expansion, risk
    resultado JSONB,
    executed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Financeiro
CREATE TABLE financial_scenarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hybrid_scenario_id UUID REFERENCES hybrid_scenarios(id),
    nome TEXT, -- ex: "Cenário A — taxa 1,2% a.m."
    premissas JSONB,
    payback NUMERIC,
    tir NUMERIC,
    vpl NUMERIC,
    versao INT DEFAULT 1
);

CREATE TABLE financial_cashflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    financial_scenario_id UUID NOT NULL REFERENCES financial_scenarios(id),
    periodo DATE,
    fluxo NUMERIC,
    fluxo_acumulado NUMERIC
);

-- =========================================================
-- TECHNOLOGY CATALOG
-- =========================================================
CREATE TABLE manufacturers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome TEXT NOT NULL,
    categoria TEXT -- bess | solar | ambos
);

CREATE TABLE technology_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome TEXT NOT NULL
);

CREATE TABLE technology_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    manufacturer_id UUID NOT NULL REFERENCES manufacturers(id),
    category_id UUID REFERENCES technology_categories(id),
    modelo TEXT NOT NULL,
    status TEXT DEFAULT 'active'
);

CREATE TABLE technology_specs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    technology_model_id UUID NOT NULL REFERENCES technology_models(id),
    chave TEXT,
    valor TEXT
);

CREATE TABLE technology_prices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    technology_model_id UUID NOT NULL REFERENCES technology_models(id),
    preco_referencia NUMERIC,
    data DATE,
    fonte TEXT
);

CREATE TABLE technology_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    technology_model_id UUID NOT NULL REFERENCES technology_models(id),
    fonte TEXT,
    url TEXT
);

CREATE TABLE technology_certifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    technology_model_id UUID NOT NULL REFERENCES technology_models(id),
    certificacao TEXT
);

CREATE TABLE technology_compatibility (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    technology_model_id UUID NOT NULL REFERENCES technology_models(id),
    compativel_com UUID REFERENCES technology_models(id)
);

CREATE TABLE technology_availability (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    technology_model_id UUID NOT NULL REFERENCES technology_models(id),
    disponivel_brasil BOOLEAN DEFAULT true,
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =========================================================
-- GOVERNANCE / AUDITORIA / EVENTOS
-- =========================================================
CREATE TABLE events (
    event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type TEXT NOT NULL,
    organization_id UUID NOT NULL REFERENCES organizations(id),
    aggregate_type TEXT,
    aggregate_id UUID,
    actor_id UUID,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    payload JSONB,
    metadata JSONB,
    correlation_id UUID,
    causation_id UUID,
    schema_version INT DEFAULT 1
);

CREATE TABLE automation_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rule_id TEXT NOT NULL, -- AUT-001 etc.
    version INT DEFAULT 1,
    event TEXT NOT NULL,
    conditions JSONB,
    actions JSONB,
    cooldown_seconds INT,
    approval_required BOOLEAN DEFAULT false
);

CREATE TABLE automation_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    automation_rule_id UUID NOT NULL REFERENCES automation_rules(id),
    event_id UUID REFERENCES events(event_id),
    status TEXT DEFAULT 'PENDING', -- PENDING|PROCESSING|COMPLETED|FAILED|SKIPPED|WAITING_APPROVAL
    idempotency_key TEXT UNIQUE,
    executed_at TIMESTAMPTZ
);

CREATE TABLE audit_logs (
    id BIGSERIAL PRIMARY KEY,
    organization_id UUID NOT NULL REFERENCES organizations(id),
    user_id UUID REFERENCES users(id),
    acao TEXT,
    entidade TEXT,
    entidade_id UUID,
    diff JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE integration_logs (
    id BIGSERIAL PRIMARY KEY,
    integracao TEXT NOT NULL,
    status TEXT, -- CONNECTED | NOT_CONNECTED | ERROR
    detalhes JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
